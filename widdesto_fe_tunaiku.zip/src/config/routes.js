export const routes = {
    HOME:() => { return `/`; },
    LOGIN:() => { return `/login`; },


    DASHBOARD: () => { return `/dashboard`; },
    TRANSACTION: () => { return `/dashboard/transaction`; },
    TRANSACTIONNEW: () => { return `/dashboard/transaction/new`; },
    ACCOUNT: () => { return `/dashboard/account`; },
  };
  