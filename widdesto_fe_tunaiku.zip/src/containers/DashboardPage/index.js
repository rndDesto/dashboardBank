import { withStyles } from '@material-ui/core';
import useStyle from './style';
import Component from './Dashboard';

export default withStyles(useStyle)(Component);
