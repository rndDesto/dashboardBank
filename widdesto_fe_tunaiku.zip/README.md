## Setup Boilerplate
-  Install the dependencies using `npm install`

- Running the Rest API:

- For the first and second case: `npm run mock-server`

- Case third case: `npm run mock-server:auth`

- Then you can access the API documentation here, http://localhost:3200/api-docs
-  Remember that both instances cannot run simultaneously since they use the same port. Shut down the other when you want to run one, or change the port yourself.

- For running the Front-end:`npm start`